import{a as t}from"../chunks/entry.C3NC5NLF.js";export{t as start};
